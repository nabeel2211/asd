import axios from 'axios';
import React, { useEffect, useState, } from 'react';


function Posts()
{
    const divStyle = {
        width: '80%',
        margin: '0 auto',
        backgroundColor: 'lightgray',
        padding: '20px',
        textAlign: 'center',
      };

    const [posts,setPosts] = useState([]);
    const [error,setError] = useState(null);
    const [searchText,setSearchText] = useState('');
    const [loading,setLoading] = useState(true)
    const [searchedPosts, setSearchedPosts] = useState([]);

    useEffect(()=>{
        axios.get('https://jsonplaceholder.typicode.com/posts')
        .then((response)=>{
            setPosts(response.data);
            setSearchedPosts(response.data);
            setLoading(false);
        })
        .catch((error)=>{
            setError(error.message);
            setLoading(false);
        })
    },[]);

    const handleChange=() => {
        debugger;
        setSearchedPosts(searchText ?
            posts.filter((post) =>post.title.toLowerCase().includes(searchText.toLowerCase()))
            :
            posts)
    };
    

    return (
        <>
            <div style={divStyle}>
            <input type='text' placeholder='Search Posts' onChange={e => setSearchText( e.target.value)} />
            <button onClick={handleChange} >Search</button>

            {loading ?
                <p>Loading ....</p>
                :
                (error ?
                    <p>Error : {error}</p> :
                    
                    <table>
                        <thead>
                            <tr>
                                <th>
                                    Post Title
                                </th>
                                <th>
                                    Post Body
                                </th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            {searchedPosts.map((post)=>(
                                <tr key={post.id}>
                                    <td>{post.title}</td>
                                    <td>{post.body}</td>
                                </tr>
                            ))}
                        </tbody>
                        
                    </table>
                          
                    )
                    
            }
            
        </div>
        </>
        
    )

}

export default Posts;

